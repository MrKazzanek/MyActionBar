$data modify storage actionclock:player days_text set value "Day $(days)"
