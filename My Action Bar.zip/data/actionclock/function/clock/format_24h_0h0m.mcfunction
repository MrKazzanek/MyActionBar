$data modify storage actionclock:player clock_text set value "0$(hours):0$(minutes)"
