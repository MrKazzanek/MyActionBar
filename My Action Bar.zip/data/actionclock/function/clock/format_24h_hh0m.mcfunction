$data modify storage actionclock:player clock_text set value "$(hours):0$(minutes)"
