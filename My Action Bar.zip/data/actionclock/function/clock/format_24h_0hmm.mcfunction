$data modify storage actionclock:player clock_text set value "0$(hours):$(minutes)"
