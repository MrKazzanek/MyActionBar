# Wyświetlanie co tick zegara
function actionclock:display