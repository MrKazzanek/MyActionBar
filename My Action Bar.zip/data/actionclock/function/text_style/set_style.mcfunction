# Ustawienie domyślnych wartości stylu tekstu
data modify storage actionclock:player bold set value "false"
data modify storage actionclock:player underlined set value "false"
data modify storage actionclock:player italic set value "false"
data modify storage actionclock:player strikethrough set value "false"

# 1 - Podkreślenie
execute if score @s text_style matches 1 run data modify storage actionclock:player underlined set value "true"

# 2 - Pogrubienie
execute if score @s text_style matches 2 run data modify storage actionclock:player bold set value "true"

# 3 - Podkreślenie i Pogrubienie
execute if score @s text_style matches 3 run data modify storage actionclock:player underlined set value "true"
execute if score @s text_style matches 3 run data modify storage actionclock:player bold set value "true"

# 4 - Kursywa
execute if score @s text_style matches 4 run data modify storage actionclock:player italic set value "true"

# 5 - Kursywa i Pogrubienie
execute if score @s text_style matches 5 run data modify storage actionclock:player italic set value "true"
execute if score @s text_style matches 5 run data modify storage actionclock:player bold set value "true"

# 6 - Kursywa i Podkreślenie
execute if score @s text_style matches 6 run data modify storage actionclock:player italic set value "true"
execute if score @s text_style matches 6 run data modify storage actionclock:player underlined set value "true"

# 7 - Kursywa, Podkreślenie i Pogrubienie
execute if score @s text_style matches 7 run data modify storage actionclock:player italic set value "true"
execute if score @s text_style matches 7 run data modify storage actionclock:player underlined set value "true"
execute if score @s text_style matches 7 run data modify storage actionclock:player bold set value "true"

# 8 - Przekreślenie
execute if score @s text_style matches 8 run data modify storage actionclock:player strikethrough set value "true"

# 9 - Przekreślenie i Pogrubienie
execute if score @s text_style matches 9 run data modify storage actionclock:player strikethrough set value "true"
execute if score @s text_style matches 9 run data modify storage actionclock:player bold set value "true"

# 10 - Przekreślenie i Podkreślenie
execute if score @s text_style matches 10 run data modify storage actionclock:player strikethrough set value "true"
execute if score @s text_style matches 10 run data modify storage actionclock:player underlined set value "true"

# 11 - Przekreślenie i Kursywa
execute if score @s text_style matches 11 run data modify storage actionclock:player strikethrough set value "true"
execute if score @s text_style matches 11 run data modify storage actionclock:player italic set value "true"

# 12 - Wszystko (Pogrubienie, Podkreślenie, Kursywa, Przekreślenie)
execute if score @s text_style matches 12 run data modify storage actionclock:player bold set value "true"
execute if score @s text_style matches 12 run data modify storage actionclock:player underlined set value "true"
execute if score @s text_style matches 12 run data modify storage actionclock:player italic set value "true"
execute if score @s text_style matches 12 run data modify storage actionclock:player strikethrough set value "true"
