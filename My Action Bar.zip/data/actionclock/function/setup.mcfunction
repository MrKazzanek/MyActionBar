
# Scoreboardy obliczeń
scoreboard objectives add actionclock_time dummy
scoreboard objectives add actionclock_hours dummy
scoreboard objectives add actionclock_minutes dummy
scoreboard objectives add action_pack_notice dummy

# Stałe 
scoreboard players set #day_length actionclock_time 24000
scoreboard players set #hour_ticks actionclock_time 1000
scoreboard players set #const60 actionclock_time 60
scoreboard players set #timer actionclock_time 0

# Triggery ustawień graczy 
scoreboard objectives add show trigger
scoreboard objectives add show_clock trigger
scoreboard objectives add default trigger
scoreboard objectives add set_color trigger
scoreboard objectives add dynamic_clock_color trigger
scoreboard objectives add show_weather_info trigger
scoreboard objectives add show_days trigger
scoreboard objectives add show_days_prefix trigger
scoreboard objectives add show_cordinates trigger
scoreboard objectives add show_cordinates_prefix trigger
scoreboard objectives add separators trigger
scoreboard objectives add external_separators trigger
scoreboard objectives add display_order trigger
scoreboard objectives add weather_info_type trigger
scoreboard objectives add time_format trigger
scoreboard objectives add text_style trigger
scoreboard objectives add show_facing_direction trigger
scoreboard objectives add facing_direction_type trigger
scoreboard objectives add facing_direction_advanced trigger
scoreboard objectives add show_player_head trigger
scoreboard objectives add version trigger "My Action Bar Version"
# Rejestracja triggera losowania
scoreboard objectives add random trigger "Randomize Actionbar Settings"

# Ustawienia włączone dla graczy
scoreboard players enable @a show
scoreboard players enable @a show_clock
scoreboard players enable @a default
scoreboard players enable @a set_color
scoreboard players enable @a dynamic_clock_color
scoreboard players enable @a show_weather_info
scoreboard players enable @a show_days
scoreboard players enable @a show_days_prefix
scoreboard players enable @a show_cordinates
scoreboard players enable @a show_cordinates_prefix
scoreboard players enable @a separators
scoreboard players enable @a external_separators
scoreboard players enable @a display_order
scoreboard players enable @a weather_info_type
scoreboard players enable @a time_format
scoreboard players enable @a text_style
scoreboard players enable @a show_facing_direction
scoreboard players enable @a facing_direction_type
scoreboard players enable @a facing_direction_advanced
scoreboard players enable @a show_player_head

execute as @a unless score @s action_pack_notice matches 1 run function actionclock:first_setup

# Debugowe 


# execute as @a run scoreboard players set @s dynamic_clock_color 1
# execute as @a run scoreboard players set @s show_weather_info 1
# execute as @a run scoreboard players set @s show_days 1
# execute as @a run scoreboard players set @s show_days_prefix 0
# execute as @a run scoreboard players set @s show_cordinates 0
# execute as @a run scoreboard players set @s show_cordinates_prefix 0



# Developer API Hook
function #actionclock:api/setup

# say [ActionClock v2] Zaladowany!