$data modify storage actionclock:player coords_text set value "$(x) $(y) $(z)"
