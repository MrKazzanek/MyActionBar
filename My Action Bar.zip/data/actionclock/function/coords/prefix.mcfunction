$data modify storage actionclock:player coords_text set value "X: $(x) Y: $(y) Z: $(z)"
