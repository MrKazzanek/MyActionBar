# Acualy time get
execute store result score #raw_time actionclock_time run time query day
execute store result score #days actionclock_time run time query day repetition
execute store result storage actionclock:display days int 1 run scoreboard players get #days actionclock_time



# raw time
scoreboard players operation #shifted actionclock_time = #raw_time actionclock_time
scoreboard players add #shifted actionclock_time 6000

# modulo
scoreboard players operation #shifted actionclock_time %= #day_length actionclock_time

# hours
scoreboard players operation #hours actionclock_time = #shifted actionclock_time
scoreboard players operation #hours actionclock_time /= #hour_ticks actionclock_time

# modulo hours
scoreboard players operation #ticks_in_hour actionclock_time = #shifted actionclock_time
scoreboard players operation #ticks_in_hour actionclock_time %= #hour_ticks actionclock_time

# minutes
scoreboard players operation #minutes actionclock_time = #ticks_in_hour actionclock_time
scoreboard players operation #minutes actionclock_time *= #const60 actionclock_time
scoreboard players operation #minutes actionclock_time /= #hour_ticks actionclock_time